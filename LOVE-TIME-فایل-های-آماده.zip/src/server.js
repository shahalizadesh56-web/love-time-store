import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import crypto from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { z } from 'zod';
import { db } from '../db.js';

const app = express();
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const ROOT = path.join(__dirname, '..');

app.use(cors());
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true }));

const sendPage = (name) => (req, res) =>
  res.sendFile(path.join(ROOT, name));

app.get('/', sendPage('فهرست.html'));
app.get('/index.html', sendPage('فهرست.html'));
app.get('/admin', sendPage('admin.html'));
app.get('/admin.html', sendPage('admin.html'));

const orderSchema = z.object({
  customer: z.object({
    name: z.string().trim().min(2).max(100),
    phone: z.string().trim().regex(/^09\d{9}$/),
    address: z.string().trim().min(8).max(500)
  }),
  items: z.array(z.object({
    productId: z.coerce.number().int().positive(),
    quantity: z.coerce.number().int().min(1).max(50)
  })).min(1).max(100)
});

function makeOrderNo() {
  let no;
  do {
    no = 'LT-' + crypto.randomInt(10000000, 99999999);
  } while (db.prepare('SELECT 1 FROM orders WHERE order_no=?').get(no));
  return no;
}

app.get('/api/health', (req, res) => {
  res.json({ ok: true, service: 'LOVE TIME API' });
});

app.get('/api/products', (req, res) => {
  try {
    res.json(db.prepare(
      'SELECT * FROM products WHERE active=1 ORDER BY id DESC'
    ).all());
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'خطا در دریافت محصولات.' });
  }
});

app.get('/api/products/:id', (req, res) => {
  try {
    const product = db.prepare(
      'SELECT * FROM products WHERE id=? AND active=1'
    ).get(Number(req.params.id));

    if (!product) return res.status(404).json({ error: 'محصول پیدا نشد.' });
    res.json(product);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'خطا در دریافت محصول.' });
  }
});

app.post('/api/orders', (req, res) => {
  try {
    const parsed = orderSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ error: 'اطلاعات سفارش نامعتبر است.' });
    }

    const ids = parsed.data.items.map(x => x.productId);
    const uniqueIds = [...new Set(ids)];
    const placeholders = uniqueIds.map(() => '?').join(',');

    const products = db.prepare(
      `SELECT * FROM products WHERE active=1 AND id IN (${placeholders})`
    ).all(...uniqueIds);

    if (products.length !== uniqueIds.length) {
      return res.status(400).json({ error: 'یکی از محصولات موجود نیست.' });
    }

    const map = new Map(products.map(p => [p.id, p]));
    let total = 0;

    const normalizedItems = parsed.data.items.map(item => {
      const product = map.get(item.productId);
      if (!product) throw new Error('Product not found');
      total += Number(product.price) * item.quantity;
      return { product, quantity: item.quantity };
    });

    const orderNo = makeOrderNo();

    db.transaction(() => {
      const order = db.prepare(`
        INSERT INTO orders
        (order_no, customer_name, phone, address, total, status)
        VALUES (?, ?, ?, ?, ?, 'pending')
      `).run(
        orderNo,
        parsed.data.customer.name,
        parsed.data.customer.phone,
        parsed.data.customer.address,
        total
      );

      const insert = db.prepare(`
        INSERT INTO order_items
        (order_id, product_id, name, price, quantity)
        VALUES (?, ?, ?, ?, ?)
      `);

      for (const item of normalizedItems) {
        insert.run(
          order.lastInsertRowid,
          item.product.id,
          item.product.name,
          item.product.price,
          item.quantity
        );
      }
    })();

    res.status(201).json({
      ok: true,
      orderNo,
      amount: total,
      payment: {
        mode: 'demo',
        message: 'سفارش با موفقیت ثبت شد. پرداخت آنلاین درگاه واقعی هنوز فعال نشده است.'
      }
    });
  } catch (error) {
    console.error('CREATE ORDER ERROR:', error);
    res.status(500).json({ error: 'خطا در ثبت سفارش. لطفاً دوباره تلاش کنید.' });
  }
});

app.get('/api/orders/:orderNo', (req, res) => {
  try {
    const order = db.prepare(
      'SELECT * FROM orders WHERE order_no=?'
    ).get(req.params.orderNo);

    if (!order) return res.status(404).json({ error: 'سفارش پیدا نشد.' });

    const items = db.prepare(
      'SELECT product_id,name,price,quantity FROM order_items WHERE order_id=?'
    ).all(order.id);

    res.json({ ...order, items });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'خطا در دریافت سفارش.' });
  }
});

const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || '';

function adminAuth(req, res, next) {
  if (!ADMIN_PASSWORD) {
    return res.status(503).json({
      error: 'ADMIN_PASSWORD در تنظیمات Render تعریف نشده است.'
    });
  }

  if (req.get('x-admin-password') !== ADMIN_PASSWORD) {
    return res.status(401).json({ error: 'رمز مدیریت اشتباه است.' });
  }

  next();
}

app.get('/api/admin/orders', adminAuth, (req, res) => {
  try {
    const orders = db.prepare(
      'SELECT * FROM orders ORDER BY id DESC'
    ).all();

    const items = db.prepare(`
      SELECT product_id,name,price,quantity
      FROM order_items WHERE order_id=?
    `);

    res.json(orders.map(order => ({
      ...order,
      items: items.all(order.id)
    })));
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'خطا در دریافت سفارش‌ها.' });
  }
});

app.patch('/api/admin/orders/:orderNo', adminAuth, (req, res) => {
  const allowed = ['pending', 'confirmed', 'shipped', 'completed', 'cancelled'];

  if (!allowed.includes(req.body?.status)) {
    return res.status(400).json({ error: 'وضعیت نامعتبر است.' });
  }

  try {
    const result = db.prepare(
      'UPDATE orders SET status=? WHERE order_no=?'
    ).run(req.body.status, req.params.orderNo);

    if (!result.changes) {
      return res.status(404).json({ error: 'سفارش پیدا نشد.' });
    }

    res.json({ ok: true });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'خطا در تغییر وضعیت سفارش.' });
  }
});

app.get('/api/admin/products', adminAuth, (req, res) => {
  try {
    res.json(db.prepare(
      'SELECT * FROM products ORDER BY id DESC'
    ).all());
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'خطا در دریافت محصولات.' });
  }
});

app.post('/api/admin/products', adminAuth, (req, res) => {
  const schema = z.object({
    name: z.string().trim().min(2).max(150),
    category: z.string().trim().min(2).max(80),
    price: z.coerce.number().int().nonnegative(),
    image: z.string().trim().max(1000).optional().default(''),
    description: z.string().trim().max(1000).optional().default('')
  });

  const parsed = schema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: 'اطلاعات محصول نامعتبر است.' });
  }

  try {
    const result = db.prepare(`
      INSERT INTO products(name,category,price,image,description,active)
      VALUES(?,?,?,?,?,1)
    `).run(
      parsed.data.name,
      parsed.data.category,
      parsed.data.price,
      parsed.data.image,
      parsed.data.description
    );

    res.status(201).json({ ok: true, id: result.lastInsertRowid });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'خطا در ثبت محصول.' });
  }
});

app.patch('/api/admin/products/:id', adminAuth, (req, res) => {
  const schema = z.object({
    name: z.string().trim().min(2).max(150),
    category: z.string().trim().min(2).max(80),
    price: z.coerce.number().int().nonnegative(),
    image: z.string().trim().max(1000).optional().default(''),
    description: z.string().trim().max(1000).optional().default(''),
    active: z.coerce.number().int().min(0).max(1)
  });

  const parsed = schema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: 'اطلاعات محصول نامعتبر است.' });
  }

  try {
    const result = db.prepare(`
      UPDATE products
      SET name=?, category=?, price=?, image=?, description=?, active=?
      WHERE id=?
    `).run(
      parsed.data.name,
      parsed.data.category,
      parsed.data.price,
      parsed.data.image,
      parsed.data.description,
      parsed.data.active,
      Number(req.params.id)
    );

    if (!result.changes) {
      return res.status(404).json({ error: 'محصول پیدا نشد.' });
    }

    res.json({ ok: true });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'خطا در بروزرسانی محصول.' });
  }
});

const PORT = Number(process.env.PORT || 3000);

app.listen(PORT, '0.0.0.0', () => {
  console.log(`LOVE TIME API running on port ${PORT}`);
});
